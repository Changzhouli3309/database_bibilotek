-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: bibliotek
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `magazines`
--

DROP TABLE IF EXISTS `magazines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `magazines` (
  `id` bigint DEFAULT NULL,
  `Title` text,
  `ReleaseDate` datetime DEFAULT NULL,
  `StorageSpace` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magazines`
--

LOCK TABLES `magazines` WRITE;
/*!40000 ALTER TABLE `magazines` DISABLE KEYS */;
INSERT INTO `magazines` VALUES (1,'Illustrerad angest','2020-12-12 00:00:00','Hylla A'),(2,'Illustrerad angest','1985-10-20 00:00:00','Hylla A'),(3,'Illustrerad angest','1985-10-11 00:00:00','Hylla A'),(4,'Veckans Trakigaste','1998-01-01 00:00:00','Hylla A'),(5,'Veckans Trakigaste','2012-11-05 00:00:00','Hylla A'),(6,'Dagens Tidning','2010-11-11 00:00:00','Hylla B'),(7,'Dagens Tidning','2010-11-10 00:00:00','Hylla B'),(8,'Dagens Tidning','2010-11-09 00:00:00','Hylla B'),(9,'Dagens Tidning','2012-04-05 00:00:00','Hylla B'),(10,'Dagens Tidning','2008-10-05 00:00:00','Hylla B'),(11,'Gardagens Tidning','1988-10-10 00:00:00','Hylla C'),(12,'Gardagens Tidning','1975-04-05 00:00:00','Hylla C'),(13,'Gardagens Tidning','1992-10-10 00:00:00','Hylla C'),(14,'Gardagens Tidning','1944-02-03 00:00:00','Hylla C'),(15,'Gardagens Tidning','1957-11-24 00:00:00','Hylla C'),(16,'Gardagens Tidning','1922-12-01 00:00:00','Hylla C'),(17,'Nyheter fran Vattenpolen','2001-06-13 00:00:00','Hylla B'),(18,'Nyheter fran Vattenpolen','2003-11-04 00:00:00','Hylla B'),(19,'Nyheter fran Vattenpolen','2010-04-13 00:00:00','Hylla B'),(20,'Nyheter fran Vattenpolen','2000-01-04 00:00:00','Hylla B'),(21,'Nyheter fran Vattenpolen','2015-06-26 00:00:00','Hylla B'),(22,'Moderna trasor','2001-01-05 00:00:00','Hylla A'),(23,'Moderna trasor','2005-08-10 00:00:00','Hylla A'),(24,'Moderna trasor','2017-10-17 00:00:00','Hylla A'),(25,'Moderna trasor','2018-02-02 00:00:00','Hylla A'),(26,'Moderna trasor','2005-08-20 00:00:00','Hylla A'),(27,'Burksamlaren','2012-03-05 00:00:00','Hylla C'),(28,'Burksamlaren','2012-03-07 00:00:00','Hylla C'),(29,'Burksamlaren','2012-03-09 00:00:00','Hylla C');
/*!40000 ALTER TABLE `magazines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-22  9:36:45
